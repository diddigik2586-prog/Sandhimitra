# Sandhimitra project checkpoint — 04 Nov 2026 (active design/build)

## Locked product decisions
- Product: सन्धिमित्रम् — Sandhimitra; native Android; Kotlin, Jetpack Compose, Material 3; offline-first.
- Interface languages: Sanskrit, Kannada and English.
- Theme: **Indigo & Copper**, replacing Rosewood. Light: background `#F0F2F8`, card `#FFFFFF`, primary `#394B78`, accent `#C17B55`, text `#28334D`. Dark: background `#171E30`, card `#262F49`, primary `#D18B63`, accent `#E6AE88`, text `#F0F2F8`.
- Use the exact user-supplied application icon; do not redesign or substitute it.
- Splash: five seconds; app name in Sanskrit and English; progress bar only; no loading label; exact creator footer.
- Six home cards: Introduction; Vowel Sandhi; Consonant Sandhi; Visarga Sandhi; Prakṛtibhāva Sandhi; Sandhini Engine.
- Lesson / Practice capsules appear only after opening cards 2–4; never on homepage and not on cards 1 or 5.
- Top-right unlabeled menu; auto-close after selection. Languages: Sanskrit, Kannada, English. Include theme and text-size controls.
- About App, About Dr. DVK, Support Sandhimitra and Feedback are English-only. Feedback email: `dvkrishna92@gmail.com`.
- Exact footer on every screen: `Compiled and Created by` / `©Dr. Diddigi Vamsi Krishna`.
- No fabricated engine results. Return only registered, verified rule records; show all recorded vikalpas distinctly; reject unsupported or ambiguous inputs.
- Do not reproduce prohibited honorific terms or source-book titles in app UI/content/metadata.

## Current implementation
- Native Android Compose scaffold, six home cards and section navigation retained.
- Updated UI to Indigo & Copper Light/Dark palette.
- Lesson/Practice capsules restricted to Vowel, Consonant and Visarga sections.
- Supplied icon retained.
- Five-second splash with progress bar only and creator attribution implemented.
- English-only About App, About Dr. DVK, Support and Feedback views added; feedback opens an email intent to the supplied address.
- Language, theme and text-size controls are present in the top-right menu.
- Sanskrit and Kannada Word documents extracted into separate JSON assets for editorial structuring. Extraction assets are not yet approved as app-ready lesson content.
- Engine remains a deliberately small exact-match seed set. It must not be represented as complete sandhi coverage.

## Verification / build status
- `tests/verify_source_assets.py` checks both language extraction files, prohibited honorific exclusion, palette, capsule placement and conservative engine behavior.
- GitHub repository is public and readable, but the connected GitHub integration returned HTTP 403 `Resource not accessible by integration` for both Contents API and Git blob writes. Repository changes could not yet be committed through the current connection.
- This runtime has no Gradle executable, Gradle wrapper JAR, Android SDK or configured `ANDROID_HOME`; no APK has been built or tested here.
- `.github/workflows/android-apk.yml` is prepared to build a debug APK with GitHub Actions and upload it as a workflow artifact once committed to the repository.
- Do not claim an APK exists until GitHub Actions or a local Android SDK build succeeds and the APK is verified.

## Next engineering tasks
1. Commit the source and workflow to `diddigik2586-prog/Sandhimitra` after GitHub integration write permission is granted.
2. Run the GitHub Actions Android build and resolve actual compiler/test failures.
3. Normalize source sections, rules, examples, exceptions and vikalpas into typed rule records; review each before activation.
4. Complete Sanskrit and Kannada lesson/practice content; author independent scholarly English content.
5. Implement persistent preferences, bookmarks, lesson completion, practice attempts and history.
6. Add the hybrid Devanagari/IAST input keyboard and searchable sūtra repository.
7. Run unit/regression tests, install on physical Android devices, and verify navigation, accessibility, font rendering and offline behavior.
