import json, pathlib, re
ROOT = pathlib.Path(__file__).resolve().parents[1]
CONTENT = ROOT / 'app/src/main/assets/content'
FORBIDDEN = re.compile(r'mahāmahopādhyāya|mahāmahopadhyāya|महामहोपाध्याय|ಮಹಾಮಹೋಪಾಧ್ಯಾಯ', re.I)

for language in ('sanskrit', 'kannada'):
    asset = CONTENT / f'{language}_source_extraction.json'
    data = json.loads(asset.read_text(encoding='utf-8'))
    assert data['paragraph_count'] == len(data['paragraphs']), language
    assert data['table_count'] == len(data['tables']), language
    assert data['paragraph_count'] > 1000, language
    assert data['table_count'] > 50, language
    all_text = '\n'.join(p['text'] for p in data['paragraphs'])
    all_text += '\n' + '\n'.join('\n'.join(row) for table in data['tables'] for row in table['rows'])
    assert not FORBIDDEN.search(all_text), f'prohibited honorific in {language} extraction'

source = (ROOT / 'app/src/main/java/org/sandhimitra/app/MainActivity.kt').read_text(encoding='utf-8')
for colour in ('0xFFF0F2F8','0xFFFFFFFF','0xFF394B78','0xFFC17B55','0xFF28334D','0xFF171E30','0xFF262F49','0xFFD18B63','0xFFE6AE88'):
    assert colour in source, colour
assert 'if (section == Section.VOWEL || section == Section.CONSONANT || section == Section.VISARGA)' in source
assert 'VerifiedRules.lookup(key,direction)' in source
assert 'if(result==null) dialog=true' in source
assert 'dvkrishna92@gmail.com' in source
assert 'Support Sandhimitra' in source
assert 'Text Size: Larger' in source
print('PASS: Sanskrit/Kannada source extraction integrity, honorific exclusion, Indigo & Copper palette, capsule placement, conservative lookup and information menu')
