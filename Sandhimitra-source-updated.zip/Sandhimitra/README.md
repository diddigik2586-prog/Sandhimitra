# सन्धिमित्रम् — Sandhimitra

Native Android Sanskrit sandhi learning and analysis application built with Kotlin, Jetpack Compose and Material 3. Offline-first; Sanskrit, Kannada and English interface.

## Current implementation checkpoint
- Six-card home screen: Introduction; Vowel Sandhi; Consonant Sandhi; Visarga Sandhi; Prakṛtibhāva Sandhi; Sandhini Engine.
- Lesson / Practice selector only inside Vowel, Consonant and Visarga sections.
- Indigo & Copper Light/Dark theme using the exact palette recorded in `docs/PROJECT_CHECKPOINT.md`.
- Supplied app icon retained; five-second splash, progress bar only, Sanskrit/English app name and exact creator footer.
- English-only About App, About Dr. DVK, Support Sandhimitra and Feedback views.
- Sanskrit and Kannada source extractions are retained as editorial source assets, not yet approved as final lesson content.
- Conservative exact-match engine seed set; unsupported input is rejected rather than guessed.

## Build
A GitHub Actions workflow is provided at `.github/workflows/android-apk.yml`. It uses JDK 17, Android SDK Platform 35 and Gradle 8.9, runs source-integrity checks, assembles the debug APK and uploads `app-debug.apk` as the `Sandhimitra-debug-apk` artifact.

Once committed, run it from GitHub → Actions → Android APK → Run workflow. Build locally with JDK 17, Android SDK Platform 35 and Gradle 8.9:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Scholarly safeguards
No rule is inferred merely to produce an answer. A form is displayed only when a verified rule record applies. Optional alternatives must be shown distinctly. Reverse Sandhi must preserve ambiguity. Unsupported input must return a clear not-yet-verified message, never an invented form.

## Before a final release
1. Structure and verify all source rules, conditions, exceptions, examples and vikalpas.
2. Complete Sanskrit and Kannada lesson coverage and author independent scholarly English lessons.
3. Add persistent progress/preferences, bookmarks, history and the hybrid Devanagari/IAST keyboard.
4. Expand the Sandhini Engine only after rule-by-rule scholarly verification.
5. Build, install and test on physical Android devices.
