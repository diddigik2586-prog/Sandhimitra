# Changelog
## 1.0.8-sample
- About page: removed the dictionary data credit line (author's decision; the licence text remains in the app assets and docs).
## 1.0.7-sample
- Removed the English-mode note about independent composition/IAST everywhere.
- About page replaced with the author's text (plus a one-line dictionary licence credit).
- Home: Introduction and Sandhātrī bars inverted (indigo with light text in light theme; copper with indigo text in dark theme).
## 1.0.6-sample
- Typing ल+ृ / ल+ॄ / ल+ॢ / ल+ॣ (and ಲ+ೃ…) in any Sandhātrī field is converted at once to the vowel ऌ / ॡ (ಌ / ೡ); the engine also reads these forms if pasted.
## 1.0.5-sample
- Input variants: ल+ृ ("लृ") is read as the vowel ऌ (likewise ॡ), IAST l̥/r̥, ':' as visarga (तव + लृकारः now gives तवल्कारः).
- Every example and exercise of the supplied tables was run through the engine (docs/CORPUS_CHECK_REPORT.txt): forward 218→264 of 281, reverse 53→69 of 81; the remainder are source-table defects.
- New: morpheme-level ayādi alternative (ने+अनम्→नयनम्, भो+अनम्→भवनम्) with ṇatva; listed vārttika exceptions (अक्षौहिणी, प्रौढः, स्वैरः, शकन्धुः, कुलटा, सारङ्गः, पतञ्जलिः, गवेन्द्रः…); ओम् (6.1.95); उद्+ल (उल्लासः); उद्+स्तम्भ; ṣ-final stems; नमस्/पुरस् (8.3.40); निः/दुः/आविः…+क/प (8.3.41); radical-r words (अन्तः, पुनः, प्रातः, स्वः, अहः) offered both ways; candrabindu variants (ताँस्तान्); dual ī/ū forms offered as pragṛhya alternative; षट्+नवतिः fix.
- Reverse analysis: no-change splits need a vowel-final left part; guess-based sandhi splits are dropped only when a clearly better no-change reading exists (dictionary-entry weight); prefixes (सु, प्र…) always kept.
## 1.0.4-sample
- Fonts: Kohinoor Devanagari for Sanskrit, Kannada MN for Kannada, Andika for English/IAST.
- Smaller wordmark on the splash (slightly smaller in the header); faint halo around the wordmark removed.
## 1.0.3-sample
- Header: app icon top-left, Sanskrit wordmark centred with its white background removed (derived transparent PNG; recoloured for dark theme), Menu right. Splash uses the same wordmark.
- Rule registry: no rule codes, no Verified chip, no explanatory line.
- Sandhi Yojana: first two fields side by side with a + between.
- Reverse analysis: when a verified no-change split exists (e.g. संहिता + पाठः), guess-based sandhi splits (संहिता + अपाठः) are no longer offered; Kannada input tested.
## 1.0.2-sample
- About App, About Dr. DVK, Support, Feedback and Privacy Policy (pages and menu labels) are English only.
- Support: bank transfer details are a collapsible dropdown.
- Sanskrit interface wording corrected (consistent 2nd-person plural imperatives, removed visarga+colon clashes, fixed case/verb forms, removed unused lexicon wording).
- Menu: Introduction entry removed (Home and Sandhātrī unchanged; Introduction still opens from the Home card).
## 1.0.1-sample
- Centre-aligned About App, About Dr. DVK, Support, Privacy.
- Support: native QR (cropped from supplied image) + payment details as text.
- Removed lexicon page and in-app keyboard (system keyboard only).
- Practice: optional answer reveal, no right/wrong marking.
- Engine: added no-change junction splits (e.g. संहिता + पाठः), nominal forms recognised via stem+ending count as verified, 8.3.35 śarpare fixed (कः त्सरति), 8.3.36 and particle rules now tested and marked verified; spurious splits of dictionary words suppressed; 'unsupported candidates' list removed from the UI.
## 1.0.0
Complete rewrite on the audited legacy scaffold: modular Compose app, 44-topic trilingual content, Sandhātrī engine (forward/reverse), MW lexicon, in-app keyboard, progress DB, About/DVK/Support/Privacy, signed release APK.
